CREATE TABLE IF NOT EXISTS todos (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  completed BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO todos (title, completed)
VALUES
  ('Learn Docker', true),
  ('Build React + Express app', false)
ON CONFLICT DO NOTHING;
