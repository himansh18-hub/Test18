# React + Express + Postgres + Docker Example

A small full-stack starter with:

- React frontend (Vite)
- Express API
- PostgreSQL database
- Docker Compose for one-command startup

## Features

- Health check endpoint
- Todo CRUD API
- React UI to list and add todos
- Postgres seed/init script

## Project structure

```text
.
├─ client/        # React app
├─ server/        # Express API
├─ db/            # SQL init script
└─ docker-compose.yml
```

## Run with Docker

```bash
docker compose up --build
```

Open:

- Frontend: http://localhost:3000
- API: http://localhost:4000/api/health

## Local development

### 1) Start Postgres

Use Docker Compose or your own Postgres instance.

### 2) Start the API

```bash
cd server
cp .env.example .env
npm install
npm run dev
```

### 3) Start the frontend

```bash
cd client
npm install
npm run dev
```

## API routes

- `GET /api/health`
- `GET /api/todos`
- `POST /api/todos`

Request body for `POST /api/todos`:

```json
{
  "title": "Buy milk"
}
```
