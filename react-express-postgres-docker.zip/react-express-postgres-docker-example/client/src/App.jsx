import { useEffect, useState } from 'react';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:4000';

export default function App() {
  const [todos, setTodos] = useState([]);
  const [title, setTitle] = useState('');
  const [status, setStatus] = useState('Loading...');

  useEffect(() => {
    loadTodos();
  }, []);

  async function loadTodos() {
    try {
      const res = await fetch(`${API_URL}/api/todos`);
      const data = await res.json();
      setTodos(data);
      setStatus('Connected to API and Postgres');
    } catch (error) {
      setStatus('Could not load todos');
    }
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!title.trim()) return;

    await fetch(`${API_URL}/api/todos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title }),
    });

    setTitle('');
    await loadTodos();
  }

  return (
    <main className="app">
      <section className="card">
        <h1>React + Express + Postgres</h1>
        <p className="status">{status}</p>

        <form onSubmit={handleSubmit} className="form">
          <input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Add a todo"
          />
          <button type="submit">Add</button>
        </form>

        <ul className="list">
          {todos.map((todo) => (
            <li key={todo.id} className="item">
              <span>{todo.title}</span>
              <small>{todo.completed ? 'Done' : 'Open'}</small>
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
