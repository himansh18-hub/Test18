import React, { useState } from 'react';
import { gql, useMutation } from '@apollo/client';

const ADD_USER = gql`
  mutation AddUser($name: String!, $email: String!) {
    addUser(name: $name, email: $email) {
      id
      name
      email
    }
  }
`;

const GET_USERS = gql`
  query {
    users {
      id
      name
      email
    }
  }
`;

function AddUser() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');

  const [addUser] = useMutation(ADD_USER, {
    optimisticResponse: {
      addUser: {
        id: "temp-id",
        name,
        email,
        __typename: "User"
      }
    },

    update(cache, { data: { addUser } }) {
      const existing = cache.readQuery({
        query: GET_USERS
      });

      cache.writeQuery({
        query: GET_USERS,
        data: {
          users: [...existing.users, addUser]
        }
      });
    }
  });

  const handleAdd = async () => {
    await addUser({
      variables: { name, email },
      context: {
        headers: {
          authorization: 'dummy'
        }
      }
    });

    setName('');
    setEmail('');
  };

  return (
    <div>
      <input
        placeholder="Name"
        value={name}
        onChange={e => setName(e.target.value)}
      />

      <input
        placeholder="Email"
        value={email}
        onChange={e => setEmail(e.target.value)}
      />

      <button onClick={handleAdd}>
        Add User
      </button>
    </div>
  );
}

export default AddUser;
