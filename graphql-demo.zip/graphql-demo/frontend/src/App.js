import React from 'react';
import { ApolloProvider } from '@apollo/client';

import client from './apollo';
import Users from './components/Users';
import AddUser from './components/AddUser';

function App() {
  return (
    <ApolloProvider client={client}>
      <div style={{ padding: 20 }}>
        <h1>GraphQL Demo</h1>
        <AddUser />
        <Users />
      </div>
    </ApolloProvider>
  );
}

export default App;
