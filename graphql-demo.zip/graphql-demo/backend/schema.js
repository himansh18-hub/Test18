const { gql } = require('apollo-server');

const typeDefs = gql`
  type User {
    id: ID!
    name: String!
    email: String!
  }

  type AuthPayload {
    token: String!
    user: User!
  }

  type UserPage {
    users: [User]
    totalCount: Int
    nextCursor: String
  }

  type Query {
    users: [User]
    user(id: ID!): User
    paginatedUsers(limit: Int!, cursor: String): UserPage
  }

  type Mutation {
    addUser(name: String!, email: String!): User
    login(email: String!): AuthPayload
  }
`;

module.exports = typeDefs;
