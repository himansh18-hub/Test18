const users = [
  {
    id: "1",
    name: "John",
    email: "john@test.com"
  },
  {
    id: "2",
    name: "Alice",
    email: "alice@test.com"
  }
];

module.exports = users;
