const jwt = require('jsonwebtoken');
const users = require('./data');

const resolvers = {
  Query: {
    users: () => users,

    user: (_, { id }) => {
      return users.find(user => user.id === id);
    },

    paginatedUsers: (_, { limit, cursor }) => {
      let startIndex = 0;

      if (cursor) {
        startIndex = users.findIndex(user => user.id === cursor) + 1;
      }

      const paginated = users.slice(startIndex, startIndex + limit);

      const nextCursor =
        paginated.length > 0
          ? paginated[paginated.length - 1].id
          : null;

      return {
        users: paginated,
        totalCount: users.length,
        nextCursor
      };
    }
  },

  Mutation: {
    addUser: (_, { name, email }, context) => {
      if (!context.user) {
        throw new Error("Unauthorized");
      }

      const newUser = {
        id: String(users.length + 1),
        name,
        email
      };

      users.push(newUser);

      return newUser;
    },

    login: (_, { email }) => {
      const user = users.find(u => u.email === email);

      if (!user) {
        throw new Error("User not found");
      }

      const token = jwt.sign(
        { userId: user.id },
        "SECRET_KEY"
      );

      return {
        token,
        user
      };
    }
  }
};

module.exports = resolvers;
