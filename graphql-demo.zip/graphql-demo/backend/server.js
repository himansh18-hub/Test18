const { ApolloServer } = require('apollo-server');

const typeDefs = require('./schema');
const resolvers = require('./resolvers');
const getUser = require('./auth');

const server = new ApolloServer({
  typeDefs,
  resolvers,

  context: ({ req }) => {
    const token = req.headers.authorization || '';
    const user = getUser(token);

    return { user };
  },

  formatError: (err) => {
    return {
      message: err.message,
      code: err.extensions.code
    };
  }
});

server.listen(4000).then(() => {
  console.log('Server running on http://localhost:4000');
});
