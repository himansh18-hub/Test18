const jwt = require('jsonwebtoken');

const getUser = (token) => {
  if (!token) return null;

  try {
    return jwt.verify(token, "SECRET_KEY");
  } catch {
    return null;
  }
};

module.exports = getUser;
